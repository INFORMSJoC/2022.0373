function [ specificity ] = specMAM_MRI( time )



    specificity = 0.86;

% Granader EJ, Dwamena B, Carlos RC. MRI and mammography surveillance of
% women at increased risk for breast cancer: recommendations using an evidence-based approach. Acad Radiol. 15(12):1590-5, 2008 

end

